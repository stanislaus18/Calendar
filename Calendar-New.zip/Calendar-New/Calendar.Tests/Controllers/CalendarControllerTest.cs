﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Calendar.Controllers;
using System.Web.Mvc;

namespace Calendar.Tests.Controllers
{
    [TestClass]
    public class CalendarControllerTest
    {
        [TestMethod]
        public void Initial()
        {
            // Arrange            
            CalendarController calendar = new CalendarController();

            // Act
            ViewResult result = calendar.Initial("Jan") as ViewResult;

            // Assert
            Assert.IsNotNull(result);

        }
    }
}
