﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Calendar.Models;
using System.Collections.Generic;

namespace Calendar.Tests.DataAccessLayerTest
{
    [TestClass]
    public class DataAccessLayerTest
    {
        [TestMethod]        
        public void checkGetDetails()
        {
            //Inital Data
            string month = "Feb";

            // Arrange            
            DataAccessLayer dAL = new DataAccessLayer();

            // Act
            var result = dAL.getDetails(month);

            // Assert
            Assert.IsInstanceOfType(result, typeof(List<MonthsAppointment>));
        }
    }
}
