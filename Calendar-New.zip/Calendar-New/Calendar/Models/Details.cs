﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Calendar.Models
{
    public class Details
    {
        public int ID { get; set; }
        public string attendees { get; set; }
    }
}