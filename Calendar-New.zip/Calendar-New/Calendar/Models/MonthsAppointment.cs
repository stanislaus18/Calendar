﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Calendar.Models
{
    public class MonthsAppointment
    {
        public int ID { get; set; }
        public string month { get; set; }
        public DateTime appointmentDate { get; set; }
        public string shortDescription { get; set; }
        public string organizer { get; set; }
        public List<Details> details { get; set; }
    }
}