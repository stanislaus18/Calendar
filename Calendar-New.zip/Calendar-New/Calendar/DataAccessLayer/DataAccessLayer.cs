﻿using Calendar.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;

namespace Calendar
{
    public class DataAccessLayer
    {
        string sqlCon = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=|DataDirectory|Calendar.mdf;Integrated Security=True";

        public List<MonthsAppointment> getDetails(string month) {
            SqlConnection Con = new SqlConnection(sqlCon);
            string queryString =
                "SELECT Mn.Id, Mn.Month, Mn.Short_Desc, Mn.date, Cdesc.Organizers, Cdesc.Attendees FROM Months Mn" +
                " JOIN " +
                "(SELECT MDP.Id,MDP.name AS Organizers, MPA.name AS Attendees FROM " +
                "(select MD.Id, MD.Organizer, MD.MeetingNo, P.name from MeetingDetails MD Join Persons P on MD.Organizer = P.Id) as MDP" +
                " JOIN " +
                "(select M.Id, P.name from Meeting M Join Persons P on M.person = P.Id) as MPA On MDP.MeetingNo = MPA.Id) as Cdesc " +
                "ON Mn.Large_Desc = Cdesc.Id where Mn.Month = '" +month+"'";

            if (!String.IsNullOrEmpty(month)) {
                SqlCommand command = new SqlCommand(queryString, Con);
                List<MonthsAppointment> lMonthAppointment = new List<MonthsAppointment>();
                try
                {
                    Con.Open();
                    SqlDataReader reader = command.ExecuteReader();
                    while (reader.Read())
                    {
                        MonthsAppointment data;
                        Boolean found = false;
                        data = lMonthAppointment.Find(x => x.ID == Convert.ToInt32(reader[0]));
                        if (data == null)
                        {
                            data = new MonthsAppointment
                            {
                                ID = Convert.ToInt32(reader[0]),
                                month = Convert.ToString(reader[1]),
                                shortDescription = Convert.ToString(reader[2]),
                                appointmentDate = Convert.ToDateTime(reader[3]),
                                organizer = Convert.ToString(reader[4]),
                                details = new List<Details>()
                            };
                        }
                        else
                        {
                            found = true;
                        }
                        data.details.Add(new Details
                        {
                            ID = Convert.ToInt32(reader[0]),
                            attendees = Convert.ToString(reader[5])
                        });
                        if (!found)
                        {
                            lMonthAppointment.Add(data);
                        }
                    }
                    reader.Close();
                    Con.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                }
                return lMonthAppointment;
            }
            return null;
        }
    }
}